#!/usr/bin/env node
const http = require('http');
const faker = require('faker');

const port = process?.env?.port || 3333;

console.log('Starting application helloworld (port: ' + port + ')...');

http.createServer(function (request, response) {
  console.log(`Request ${request.method} ${request.url}`);
  const content = faker.fake("<h1>Lorem Ipsum</h1><p>{{lorem.paragraph}}</p><p>{{lorem.paragraph}}</p><p>{{lorem.paragraph}}</p>");
  response.end(content, 'utf-8');
}).listen(port);