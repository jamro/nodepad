const express = require('express');
const ws = require('ws');

const port = process?.env?.port;
if(!port) {
  throw new  Error('PORT env not defined');
}

const app = express();
app.set('view engine', 'ejs');

const wsServer = new ws.Server({ noServer: true });
wsServer.on('connection', socket => {
  socket.on('message', message => {
    console.log('Message received: ' + message)
    socket.send('Echo: ' + message)
  });
});

const server = app.listen(port);
server.on('upgrade', (request, socket, head) => {
  wsServer.handleUpgrade(request, socket, head, socket => {
    wsServer.emit('connection', socket, request);
  });
});

app.get('/', function(req, res){
  res.render('client');
});